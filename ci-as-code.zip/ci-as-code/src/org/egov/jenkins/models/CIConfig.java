package org.egov.jenkins.models;

public class CIConfig {

}
